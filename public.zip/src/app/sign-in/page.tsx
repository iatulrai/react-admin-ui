const LoginPage = () => {
  return (
    <div className=''>LoginPage</div>
  )
}

export default LoginPage